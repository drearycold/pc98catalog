Virtual Floppy Image Converter README.TXT       (C)Copyright 1999-2001 RED

Virtual Floppy Image Converter is FREE SOFTWARE.
The copyright of the document and software is reserved by RED. 
The copyright of 'ind88.vin','exd88.vex' is reserved by Studio Milmake. 
An author isn't responsible even if some damage arises by this software. 

Reproduction and distribution should be set free except for the following case. 
 - When a tool, a document, archive was changed. 
 - Business use (in such cases as recording to the book and so on). 

Presume vfic.txt plugin.txt you use. 

(C)Copyright 1999-2001 RED
